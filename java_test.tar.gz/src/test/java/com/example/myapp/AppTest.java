package com.example.myapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import software.amazon.awssdk.services.redshiftdata.RedshiftDataClient;

public class AppTest {

    @Test
    public void handleRequest_shouldReturnConstantValue() {
        RedshiftDataClient client;


        //Object result = function.handleRequest("echo", null);
        //assertEquals("echo", result);
    }
}
